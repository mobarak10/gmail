<?php
include("check_session.php");
include("connection.php");
error_reporting(0);
?>
<!DOCTYPE html>
<?php
include("header.php");
?>



    <div id="main-content">
        <div class="container">
            <div class="row">
                <h2 class="sendtoCustom">Add New Customer</h2>
                <form class="form-area" action="" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="">Custromer Name</label>
                        <input type="text" value="" name="name"  class="form-control" placeholder="enter name" required>
                    </div>
                    <div class="form-group">
                        <label for="">Company Name</label>
                        <input type="text" name="company" value=""  class="form-control" placeholder="enter company name" required>
                    </div>
                    <div class="form-group">
                        <label for="">Mobile</label>
                        <input type="tel" name="mobile" value=""  class="form-control" placeholder="enter mobile number" required>
                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="tel" name="email" value=""  class="form-control" placeholder="enter email" required>
                    </div>
                    <div class="form-group">
                        <label for="">Web
                        Address</label>
                        <input type="text" name="address" value=""  class="form-control" placeholder="enter web-address" required>
                    </div>
                    <div class="form-group">
                        <label for="">Address</label>
                         <textarea name="web" id="" value="" cols="30" rows="3"  class="form-control" placeholder="enter address" required></textarea>
                    </div>
                     <div class="form-group">
                        <label for="">Your Photo</label>
                        <input class="form-control" type="file" name="uploadfile" value="" required>
                    </div>
                    <input type="submit" name="submit" value="Save" class="btn btn-primary">
                </form>
            </div>
        </div>
    </div>

   <?php
    if ($_POST['submit']) {
        $nm = $_POST['name'];
        $cmp = $_POST['company'];
        $phn = $_POST['mobile'];
        $email = $_POST['email'];
        $web = $_POST['web'];
        $adrs = $_POST['address'];
        $filename = $_FILES["uploadfile"]["name"];
        $temp_name = $_FILES["uploadfile"]["tmp_name"];
        $folder = "images/".$filename;
        move_uploaded_file($temp_name, $folder);

        if ($nm!="" && $cmp!="" && $phn!="" && $email!="" && $web!=""  && $adrs!="" && $filename!="") {
            $query = "INSERT INTO `information`(`customer-name`, `company-name`, `mobile`, `email`, `web-address`, `address`, `photos`) VALUES ('$nm','$cmp','$phn','$email','$web' ,'$adrs', '$folder')";
            $data = mysqli_query($conn, $query);

            if($data){
                header('location:allCustomer.php');
            }else{
                die(mysqli_error($conn));
            }
        }else{
            echo "All field are required!";
        }
    }
    ?>


<!-- footer section -->

<?php
include("footer.php");
?>







    <!-- optional javascript -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>