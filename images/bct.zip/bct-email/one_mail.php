<?php
session_start();
error_reporting(0);
include("connection.php"); 
  $id=$_GET['id'];
  $sql="SELECT *FROM information WHERE id=$id";
  $data=mysqli_query($conn,$sql);
  $result=mysqli_fetch_assoc($data);
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
	include("header.php");
	 ?>

<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
if ($_POST['submit']) {
	// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function


//Load Composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer(true);                              		// Passing `true` enables exceptions
try {
    //Server settings
    //$mail->SMTPDebug = 2;                                 	// Enable verbose debug output
    $mail->isSMTP();                                      		// Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';    // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                                   	// Enable SMTP authentication
    $mail->Username = 'mobarak.hossain.cse12@gmail.com';                 // SMTP username
    $mail->Password = 'joykhan151390';                           	// SMTP password
    $mail->SMTPSecure = 'TLS';                            		// Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    		// TCP port to connect to

    //Recipients
    $mail->setFrom('no-reply@digitaltradingusa.com', 'US-IT SOLUTION LLC');
    $mail->addAddress($result['email']);               	// Name is optional
    // $mail->addReplyTo('info@digitaltradingusa.com', 'Digital Trading USA');
    $mail->addAddress( $result['email']);     	// Add a recipient
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         	// Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    	// Optional name

    //Content
    $mail->isHTML(true);                                  		// Set email format to HTML
    $mail->Subject = $_POST['subject'];
    $mail->Body    = $_POST['message'];
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
}
?>


<br><br>
	<div id="main-content">
        <div class="container">
            <div class="row">
                <h2 class="sendtoCustom">Send Email to Selected Customer</h2>
				<form action="" class="form-area" method="post">
					<div class="form-group">
					To <input type="text" name="to" class="form-control" value="<?php echo $result['email']?>"></div>
					<div class="form-group">
					Subject <input type="text" name="subject" class="form-control" value="" placeholder="enter subject">
					</div>
					<div class="form-group">
					Messages <input type="text" name="message" class="form-control" value="" placeholder="enter message">
					</div>
					<input type="submit" name="submit" class="btn btn-primary" value="Send Mail"><br><br>
				</form>
				</div>
	        </div>
	    </div>

	
<!-- footer section -->

<?php
include("footer.php");
?>


    <!-- optional javascript -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>