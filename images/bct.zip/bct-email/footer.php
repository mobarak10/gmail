<footer>
        <div class="container">
            <div class="row">
                <div class="footer-content">
                    <p>Copyright &copy;2019 | All Right Reserved by US IT Solution</p>
                </div>
            </div>
        </div>
</footer>