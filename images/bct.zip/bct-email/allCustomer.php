<?php
include("check_session.php");
?>
<!DOCTYPE html>
<html>
<?php
include("header.php");
?>
<?php
include("connection.php");
error_reporting(0);
$query = "SELECT * FROM information";
$data = mysqli_query($conn, $query);
$total = mysqli_num_rows($data);

if ($total != 0) {
?>

    <div id="main-content">
        <div class="container">
            <div class="row">
                <div class="content-all">
                    <h2>All Customer List</h2>
                    <table class="table table-bordered mt-3 table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Company</th>
                                <th>Mobile</th>
                                <th colspan="2">Action</th>
                            </tr>
                        </thead>
                <?php
                while ($result = mysqli_fetch_assoc($data)) {
                    echo "<tr>
                            <td>".$result['id']."</td>
                            <td>".$result['customer-name']."</td>
                            <td>".$result['company-name']."</td>
                            <td>".$result['mobile']."</td>
                            <td><a href='view.php?id=$result[id]'>View</a></td>
                            <td><a href='delete.php?id=$result[id]'  onclick = 'return checkdelete()'>Delete</a></td>
                        </tr>";
                    }
                }else{
                    echo "No record found";
                }
                ?>
                </table>
                </div>
            </div>
            <div class="row">
                <div class="pagination-section">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" tabindex="-1">Previous</a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        function checkdelete(){
            return confirm('Are you sure to delete')
        }
    </script>
                                   

<!-- footer section -->

<?php
include("footer.php");
?>

    <!-- optional javascript -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>