<?php
include("check_session.php");
?>
<!DOCTYPE html>
<html>
<?php
include("header.php");
?>

<!-- main content section -->

    <div id="main-content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="content">
                        <a href="#">
                            <div class="email-client">
                                <h2>Tool For US IT Solution Claints</h2>
                            </div>
                        </a>
                        <a href="#">
                            <div class="project-section">
                                <h2><a href="http://usitsolution.net/us-it-solution-llc-portfolios" style="color: #fff">Internal Projects</a></h2>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!-- footer section -->

    
<?php
include("footer.php");
?>







    <!-- optional javascript -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>